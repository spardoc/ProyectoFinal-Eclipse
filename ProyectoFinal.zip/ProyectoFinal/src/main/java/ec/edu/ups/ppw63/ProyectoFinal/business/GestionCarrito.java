package ec.edu.ups.ppw63.ProyectoFinal.business;

import java.util.List;

import ec.edu.ups.ppw63.ProyectoFinal.dao.CarritoDAO;
import ec.edu.ups.ppw63.ProyectoFinal.model.Carrito;
import ec.edu.ups.ppw63.ProyectoFinal.model.Producto;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;

@Stateless
public class GestionCarrito {

    @Inject
    private CarritoDAO carritoDAO;

    public void guardarCarrito(Carrito carrito) {
        if(carrito.getCodigo() == 0) {
            carritoDAO.insert(carrito);
        } else {
            carritoDAO.update(carrito);
        }
    }
    
    public Carrito obtenerCarritoPorCliente(int codigoCliente) {
        // Implementar lógica para obtener el carrito de un cliente específico
        // Esto puede requerir cambios en el CarritoDAO para buscar por codigoCliente
        return carritoDAO.read(codigoCliente);
    }
    
    public List<Carrito> getCarritos()
	{
		return carritoDAO.getAll();
	}
}
