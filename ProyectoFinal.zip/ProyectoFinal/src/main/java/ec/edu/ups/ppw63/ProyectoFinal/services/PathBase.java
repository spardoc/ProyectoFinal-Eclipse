package ec.edu.ups.ppw63.ProyectoFinal.services;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("rs")
public class PathBase extends Application 
{
	
}
