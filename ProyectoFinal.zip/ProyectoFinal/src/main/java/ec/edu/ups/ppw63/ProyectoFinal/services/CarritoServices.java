package ec.edu.ups.ppw63.ProyectoFinal.services;

import java.util.List;

import ec.edu.ups.ppw63.ProyectoFinal.business.GestionCarrito;
import ec.edu.ups.ppw63.ProyectoFinal.model.Carrito;
import ec.edu.ups.ppw63.ProyectoFinal.model.Producto;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/carritos")
public class CarritoServices {

    @Inject
    private GestionCarrito gestionCarrito;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response crearCarrito(Carrito carrito) {
        gestionCarrito.guardarCarrito(carrito);
        return Response.ok(carrito).build();
    }

    @GET
    @Path("/{codigo}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response obtenerCarrito(@PathParam("codigo") int codigo) {
        Carrito carrito = gestionCarrito.obtenerCarritoPorCliente(codigo);
        if (carrito != null) {
            return Response.ok(carrito).build();
        } else {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }
    
    

    @GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("list")
	public Response getCarritos(){
		List<Carrito> carritos = gestionCarrito.getCarritos();
		if(carritos.size()>0)
			return Response.ok(carritos).build();
		
		ErrorMessage error = new ErrorMessage(6, "No se registran productos");
		return Response.status(Response.Status.NOT_FOUND)
				.entity(error)
				.build();
		
	}
}
