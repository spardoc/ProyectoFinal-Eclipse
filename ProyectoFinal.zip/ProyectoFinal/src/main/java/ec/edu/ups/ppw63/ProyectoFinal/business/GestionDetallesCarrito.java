package ec.edu.ups.ppw63.ProyectoFinal.business;

import ec.edu.ups.ppw63.ProyectoFinal.dao.DetalleCarritoDAO;
import ec.edu.ups.ppw63.ProyectoFinal.model.DetalleCarrito;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import java.util.List;

@Stateless
public class GestionDetallesCarrito {

    @Inject
    private DetalleCarritoDAO detalleCarritoDAO;

    public void agregarDetalle(DetalleCarrito detalle) {
        detalleCarritoDAO.insert(detalle);
    }

    public void actualizarDetalle(DetalleCarrito detalle) {
        detalleCarritoDAO.update(detalle);
    }

    public DetalleCarrito obtenerDetalle(int codigo) {
        return detalleCarritoDAO.read(codigo);
    }

    public void eliminarDetalle(int codigo) {
        detalleCarritoDAO.remove(codigo);
    }

    public List<DetalleCarrito> obtenerDetallesPorCarrito(int codigoCarrito) {
        return detalleCarritoDAO.obtenerDetallesPorCarrito(codigoCarrito);
    }
}
